# Claude Code Project Instructions: multi-agent-coding

Use this pack for scoped multi-agent coding tasks.

- Read `SKILL.md` before coordinating roles.
- For local Claude Code workers, use `scripts/run_multi_agent.py --runtime claude-code`.
- Inside OpenClaw/Her, prefer ACP handoff with `adapters/claude-code/scripts/launch_claude_worker.sh --mode acp`.
- Generate task cards with `adapters/openclaw/scripts/create_task_cards.py`.
- Workers must write JSON and Markdown result reports before completion.
- Reviewers are read-only and may use review skills such as `ssrd` only when authorized.
- Main owns diff audit, validation, and final delivery.
