﻿# Changelog

本文件遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.2.0] - 2026-06-17

### Added

- Added native installer `scripts/install_native_skills.py` for Codex, Cursor, and Claude Code packages.
- Added Codex custom agent definitions under `adapters/codex/agents/`.
- Added Claude Code subagent definitions under `adapters/claude-code/agents/`.
- Added v0.2 client support model for App and CLI surfaces.

### Changed

- Reframed Codex App/CLI as native skill + native subagent first, with `codex exec` as optional bridge.
- Reframed Cursor App/CLI as native Agent Skill plus local `agent` CLI bridge for complete Worker automation.
- Reframed Claude Code App/IDE/CLI as native skill + bundled subagents first, with `claude --print` as optional bridge.
- Updated GitHub-link install docs so another agent can install the correct package directly from the repository link.

### Fixed

- Client packages now include the native installer and only the adapter assets needed by that client.
- Validation now includes native installer self-checks.

## [0.1.5] - 2026-06-17

### Fixed

- Updated GitHub-link install docs and demo references from v0.1.4/v0.1.3 to v0.1.5.
- Documented `cursor-desktop` and `claude-desktop` in the launcher example.

## [0.1.4] - 2026-06-17

### Added

- Cursor Desktop prompt mode via `--runtime cursor-desktop`.
- Claude Desktop / Claude.ai prompt mode via `--runtime claude-desktop`.
- Shared Desktop prompt helper for non-native Desktop surfaces.
- End-to-end GitHub-link install demo under `examples/end-to-end-agent-install/`.

### Changed

- Cursor docs now describe Desktop prompt/rules mode and CLI/tmux mode separately.
- Claude docs now separate Desktop/custom-skill prompt, Claude Code CLI, and OpenClaw ACP paths.
- Client packages include updated Desktop guidance and prompt-generation scripts.

## [0.1.3] - 2026-06-08

### Added

- Codex Desktop native subagent mode via `--runtime codex-native`.
- `adapters/codex/scripts/prepare_native_subagent.py` to produce spawn-ready task-card prompts for native Desktop subagents.

### Changed

- Codex adapter is now native-subagent-first, with Desktop handoff and `codex exec` as fallbacks.
- Codex docs now explain skill routing for review skills such as `ssrd` inside spawned Reviewers.

## [0.1.2] - 2026-06-08

### Added

- `docs/agent-install.md`：面向 AI agent 的安装入口，支持用户直接发送 GitHub 链接并要求安装 skill。
- `scripts/build_skill_packages.py`：生成 Codex、Cursor、Claude Code、OpenClaw 与通用协议包。
- v0.1.2 客户端专用包：`codex-multi-agent-skill`、`cursor-multi-agent-pack`、`claude-code-multi-agent-pack`。
- Codex Desktop handoff：无 Codex CLI 时可生成 Worker prompt，由 Desktop Main 安排 Worker 会话写回 result report。

### Changed

- README 下载区改为客户端矩阵，明确 Codex / Cursor / Claude Code / OpenClaw 的不同安装动作。
- 根 `SKILL.md` 增加安装分流说明，避免 agent 只安装通用协议包却缺少 launcher 依赖。

## [0.1.1] - 2026-05-28

### Added

- `BENCHMARKS.md`：汇总 SWE-bench Lite-shaped 历史归档，区分 latest/best runtime 结果。
- `bench/swebench-lite/results/latest-summary.json`：机器可读最新跑分摘要。
- v0.1.1 skill 下载包：`openclaw-multi-agent-skill-v0.1.1.zip` 与 `multi-agent-coding-skill-v0.1.1.zip`。

### Changed

- `run_swebench_lite.py` 新增 `--timeout` 与 `SWEBENCH_LITE_TIMEOUT`；Codex live run 默认 timeout 从 300s 提升到 900s。
- README 下载链接更新到 v0.1.1 release assets。

### Fixed

- 明确 Codex 最新 0/3 跑分的直接原因是 launcher timeout；保留早期 Codex `api-pagination` 成功样本作为对照。
- 清理 v0.1.0 文档/metadata 的历史不一致问题。
## [0.1.0] - 2026-05-26

### Added

- **multi-agent-coding Skill**（`SKILL.md`、`agents/openai.yaml`）：多角色协作流程、任务卡/结果报告模板、权限与安全检查清单。
- **OpenClaw v1 适配器**（`adapters/openclaw/`）：`create_task_cards.py`、`update_task_status.py`、`audit_worker_output.py`、`verify_workspace.py`、`run_local_demo.py`、`validate_all.py`；本地 `.codex-multi-agent/` 任务控制状态。
- **跨客户端薄适配层**：Cursor、Codex、Claude Code（`adapters/cursor/`、`adapters/codex/`、`adapters/claude-code/`）与统一启动器 `scripts/run_multi_agent.py`。
- **MCP 协调服务**（`mcp/multi-agent-coordinator/`）：任务/门控/审计状态的 stdio MCP 实现。
- **IDE 任务面板**（`ide/multi-agent-panel/`）：本地 Web UI 脚手架。
- **工具层**（`tools/`）：`git_tool`、`test_runner_tool`、`lint_tool`、`shell_tool`、`repo_index_tool`（stdlib，JSON 入出）。
- **记忆层**：`MEMORY.md`、`memory_log.py`、`memory_rotate.py`；`--summarize` 自动追加运行摘要。
- **基准 harness**：`bench/run_bench.py`；**SWE-bench Lite 形态**离线用例（`bench/swebench-lite/`）。
- **案例研究**：FizzBuzz 全门控绿路径（`examples/case-study-fizzbuzz/`）；多文件 Flask 形态 CLI（`examples/case-study-flask-cli/`）。
- **文档**：`docs/clients.md`、`docs/mcp-format.md`、`docs/roadmap.md`；`AGENTS.md` 仓库级角色约定。
- **反虚假完成门控**：`false_completion`、`thin_evidence`、`workspace_mismatch`、`stale_audit`、`missing_result_report_json`、`invalid_status_token`、`mission_control_exempt`、`undeclared_tool_used` / `missing_tools_used`。
- **`workspace_root` 轴心**：任务卡强制绝对工作区路径与 `verify_workspace.py` 预检。
- **审计语义修正**：`audit_worker_output.py` 仅在 `gate.status=passed` 时 `ok=true`；`changed-files.txt` 摘要漂移触发 stale audit。

### Changed

- 根 `README.md` 中文说明与客户端矩阵；OpenClaw `QUICKSTART.md` Golden Path。
- `.gitignore` 合并 `.codex-multi-agent*/` 变体目录。

### Notes

- 许可证：MIT。
- Hermes / VS Code 扩展仍为文档与脚手架阶段；实时 LLM bench 运行需各客户端 CLI 与配额。

[0.2.0]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.2.0
[0.1.5]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.1.5
[0.1.4]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.1.4
[0.1.3]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.1.3
[0.1.2]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.1.2
[0.1.1]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.1.1
[0.1.0]: https://github.com/yanqing7914/multi-agent/releases/tag/v0.1.0
