# Cursor Rules: multi-agent-coding

Use this project as a multi-agent mission-control pack.

- Read `SKILL.md` first for trigger rules and role boundaries.
- Use `QUICKSTART.md` for the Golden Path.
- Generate task cards with `adapters/openclaw/scripts/create_task_cards.py`.
- For Cursor Desktop, generate prompts with `scripts/run_multi_agent.py --runtime cursor-desktop`.
- Launch Cursor workers with `scripts/run_multi_agent.py --runtime cursor`.
- Keep `.codex-multi-agent/` local unless the user explicitly asks to commit it.
- Workers may edit only `allowed_paths`; Reviewers stay read-only.
- Main must run gate sync and scope audit before final delivery.
