# Cursor Rules: multi-agent-coding

Use this project as a multi-agent mission-control pack.

- Read `SKILL.md` first for trigger rules and role boundaries.
- Use `QUICKSTART.md` for the Golden Path.
- Generate task cards with `adapters/openclaw/scripts/create_task_cards.py`.
- Cursor App and Cursor CLI both discover this native skill from `.agents/skills`, `.cursor/skills`, or user skill directories.
- For complete Worker automation from Cursor App, use the local `agent` CLI bridge with `scripts/run_multi_agent.py --runtime cursor`.
- Use `--runtime cursor-desktop` only when the user explicitly wants a manual prompt handoff.
- Keep `.codex-multi-agent/` local unless the user explicitly asks to commit it.
- Workers may edit only `allowed_paths`; Reviewers stay read-only.
- Main must run gate sync and scope audit before final delivery.
