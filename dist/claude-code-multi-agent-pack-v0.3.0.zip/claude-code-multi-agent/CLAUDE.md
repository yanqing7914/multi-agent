# Claude Code Project Instructions: multi-agent-coding

Use this pack for scoped multi-agent coding tasks.

- Read `SKILL.md` before coordinating roles.
- Claude Code App/IDE and Claude Code CLI both discover this native skill from `.claude/skills` or user skill directories.
- Install bundled subagents from `adapters/claude-code/agents` into `.claude/agents` or `~/.claude/agents`.
- For automatic local workers, use native subagents or `scripts/run_multi_agent.py --runtime claude-code`.
- Use `--runtime claude-desktop` only when the user explicitly wants a manual prompt handoff.
- Inside OpenClaw/Her, prefer ACP handoff with `adapters/claude-code/scripts/launch_claude_worker.sh --mode acp`.
- Generate task cards with `adapters/openclaw/scripts/create_task_cards.py`.
- Workers must write JSON and Markdown result reports before completion.
- Reviewers are read-only and may use review skills such as `ssrd` only when authorized.
- Main owns diff audit, validation, and final delivery.
