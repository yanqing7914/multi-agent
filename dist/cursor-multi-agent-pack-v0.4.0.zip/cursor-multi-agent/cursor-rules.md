# Cursor Rules: multi-agent-coding

Use this project as a multi-agent mission-control pack.

- Read `SKILL.md` first for trigger rules and role boundaries.
- Use `QUICKSTART.md` for the Golden Path.
- Generate task cards with `adapters/openclaw/scripts/create_task_cards.py`.
- Cursor App and Cursor CLI both discover this native skill from `.agents/skills`, `.cursor/skills`, or user skill directories.
- Primary path (App): the Main agent dispatches each Worker/Reviewer by spawning a Cursor subagent directly (in-App delegation) with the task-card prompt + `allowed_paths`; no external CLI needed.
- Optional scripted/CI path: the `agent` CLI bridge via `scripts/run_multi_agent.py --runtime cursor` (needs `agent` + tmux). `/multitask` (Cursor 3) is a user-driven alternative.
- Use `--runtime cursor-desktop` only when neither delegation nor the `agent` CLI is available (manual prompt handoff).
- Keep `.codex-multi-agent/` local unless the user explicitly asks to commit it.
- Workers may edit only `allowed_paths`; Reviewers stay read-only.
- Main must run gate sync and scope audit before final delivery.
